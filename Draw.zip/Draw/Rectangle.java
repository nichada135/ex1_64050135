public class Rectangle extends Foot  {

    @Override
    public String createER() {
        return "Draw Rectangle";
    }   
}
