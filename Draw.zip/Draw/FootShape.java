import java.util.Scanner;

public class FootShape {

    private Foot foot;
    public void getfootTypeFromUser(String footType) {
        switch(footType) {
            case "Elipse":
                foot = new Elipse();
                break;
            case "Rectangle" :
                foot = new Rectangle();
                break;
        }
    }
    public String generateMail() {
        return foot.createER();
    }
    
    public static void main(String[] args) {
        FootShape foot= new FootShape();
        Scanner sc = new Scanner(System.in);
        System.out.print( "What to draw? 1.Elipse 2.Rectangle");
        int type = sc.nextInt();
        switch(type) {
            case 1:
                foot.getfootTypeFromUser("Elipse");
                break;
            case 2:
                foot.getfootTypeFromUser("Rectangle");
                break;
        }
        System.out.println(foot.generateMail());        
    }
}

