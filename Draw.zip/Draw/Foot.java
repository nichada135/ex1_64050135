public abstract class Foot
{
    public abstract String createER();
}
